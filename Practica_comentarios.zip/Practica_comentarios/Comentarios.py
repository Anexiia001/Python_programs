#Práctica comentarios
#Crear un "Guion de Película de Ciencia Ficción" utilizando comentarios en Python.

"""
La Expedición a Marte ha sido un éxito.

Los astronautas han aterrizado y se preparan para explorar el terreno.
"""

#Capitán García observa el paisaje marciano y piensa:
print("Capitan garcía: 'Este lugar es más impresionante de lo que imaginé.'")

#La tripulación comienza a recoger muestras de suelo y rocas.
print("Tripulación: 'Debemos ser cuidadosos.'")

#La ingeniera Rodriguez advierte:
print("Ingeniera Rodriguez: 'No sabemos qué tipo de microorganismos podrían existir aquí.'")

