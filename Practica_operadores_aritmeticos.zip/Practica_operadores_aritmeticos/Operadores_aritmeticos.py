#Práctica Operadores Artiméticos
#Crear un "Simulador de Calculadora de Calorías" utilizando operadores aritméticos en Python,
#integrando conocimientos previos sobre funciones, strings, y variables.

def calcular_calorias(carbohidratos, proteinas, grasas):
    """
    Esta función tendrá como objetivo calcular las calorías usando funciones aritméticas.
    Los carbohidratos: cantidad en gramos
    Las proteinas: cantidad en gramos
    Las grasas: cantidad en gramos
    """

    calorias = (carbohidratos * 4) + (proteinas * 4) + (grasas * 9)
    return calorias


print("Bienvenidos a la calculadora de alimentos")
calorias_totales = calcular_calorias(10, 40, 5)
print(f"calorias totales: {calorias_totales}")