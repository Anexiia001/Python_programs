#Caso práctico 1
#Crea una aplicación que modifique un string ingresado por el usuario y lo convierta a hash.

def hashineitor(nombreP, desarrollador):
    a = """
 █████╗ ███╗   ██╗███████╗██╗  ██╗██╗ █████╗
██╔══██╗████╗  ██║██╔════╝╚██╗██╔╝██║██╔══██╗
███████║██╔██╗ ██║█████╗   ╚███╔╝ ██║███████║
██╔══██║██║╚██╗██║██╔══╝   ██╔██╗ ██║██╔══██║
██║  ██║██║ ╚████║███████╗██╔╝ ██╗██║██║  ██║
╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝
    """
    print(a)
    return f"El nombre de la app es: {nombreP} y su creador es: {desarrollador}"

def rev_hash(valor):
    v1 = hash(valor)
    return v1

#Imprime el contenido de la función hashneitor
print(hashineitor("Hashineitor", "Anexiia"))

#El usuario ingresa el texto que quiere volver a hash
texto = input("Ingrese su texto: ")
#Mostrá información ingresada y convertida a hash
print(f"Su texto para convertir a hash es: {texto}")
print(f"Su texto hash es: {rev_hash(texto)}")
