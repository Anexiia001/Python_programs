#Práctica Introducción a las funciones
#Crear un "Analizador de Títulos de Libros" utilizando la función len() en Python.

#Títulos de los libros
titulo1 = "Cien años de soledad"
titulo2 = "El señor de los anillos"
titulo3 = "Don Quijote de la Mancha"

tamtit1 = len(titulo1)
tamtit2 = len(titulo2)
tamtit3 = len(titulo3)

print(f"La longitud del titulo del libro 1 es: {tamtit1}")
print(f"La longitud del titulo del libro 2 es: {tamtit2}")
print(f"La longitud del titulo del libro 3 es: {tamtit3}")