#Práctica tipos de argumentos en una función
#Programa "La Fiesta de Cumpleaños de Python" aplicando los conceptos de argumentos posicionales, de palabra clave y con valores por defecto en Python.

def organizar_fiesta(invitados, tema="Python", lugar="aula de informática"):
    print("Preparando una fiesta para", invitados, "invitados")
    print("Tema de la fiesta: ", tema)
    print("Lugar de la celebración: ", lugar)


inv = 10

organizar_fiesta(invitados=inv)
