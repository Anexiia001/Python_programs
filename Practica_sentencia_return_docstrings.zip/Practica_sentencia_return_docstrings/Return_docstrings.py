#Práctica Sentencia return y Docstrings
#Desarrollar un "Generador de Mensajes Personalizados" utilizando funciones en Python. El enfoque principal será en la
#sentencia return, la implementación de argumentos, el uso de strings y la incorporación de
#docstrings para la documentación de funciones.

def generar_mensaje(nombre, mensaje="Bienvenido al curso de Python!"):
    """Esta función creará mensajes personalizados.
    nombre -- Tomará un valor de tipo String en el que almacenará el nombre alguien.
    mensaje -- Mostrará por defecto un mensaje editado.
    """
    mensaje_completo = f"¡Hola {nombre}! {mensaje}"
    return mensaje_completo


nombre1 = "Anexiia"
resultado = generar_mensaje(nombre1)

print(resultado)