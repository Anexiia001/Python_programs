#Práctica Funciones propias de Python
#Combinar el aprendizaje de funciones básicas de Python como print, len, str, int, float, y type con la creación
#de funciones personalizadas para profundizar en la comprensión y manipulación de tipos de datos básicos.

def contar_caracteres(text):
    cantidad = len(text)

    # fraseC = print(f"La frase {frase} tiene {cantidad} de caracteres")

    print(f"La frase '{text}' tiene {cantidad} caracteres.")


def convertir_numero(arg1):
    var1 = str(arg1)
    var2 = float(arg1)

    print(f"Entero: {arg1}, Tipo {type(arg1)}")
    print(f"Cadena: {var1}, Tipo {type(var1)}")
    print(f"Flotante: {var2}, Tipo {type(var2)}")


print(contar_caracteres("Hola Mundo"))
print(convertir_numero(5))
