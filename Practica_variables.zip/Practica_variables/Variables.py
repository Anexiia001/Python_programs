#Práctica variables
#Crear un "Menú del Día de un Restaurante Gourmet" usando variables y la función print para mostrar los platos en la consola.

nombre_entrante = "Boneless"
nombre_principal = "Chilaquiles"
nombre_postre = "Pastel de Chocolate"
precio_entrante = "23 Dolares"
precio_principal = "40 Dolares"
precio_postre = "15 Dolares"

print("Menú del Día - Restaurante Gourmet")
print("--Entrante--")
print(nombre_entrante)
print("Precio:")
print(precio_entrante)
print("--Plato Principal--")
print(nombre_principal)
print("Precio:")
print(precio_principal)
print("--Postre--")
print(nombre_postre)
print("Precio:")
print(precio_postre)