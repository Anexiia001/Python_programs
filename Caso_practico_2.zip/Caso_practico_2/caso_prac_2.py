from math import e
#Caso práctico 2
#Funciones de activación RNA's

#Función ReLu
def ReLu(x):
    respuesta_ReLu = max(0, x)

    print("El resultado de la función ReLu es: ", respuesta_ReLu)

#Función Sigmond
def Sigmoid(x):
    respuesta_Sigmoid = 1 / (1 + (e **-x))

    print("El resultado de la función Sigmoid es: ", respuesta_Sigmoid)

#Función Tanh
def funcion_Tanh(y):

    def funcion_sinh(y):
        sinh1 = ((e ** y) - (e ** -y)) / 2

        return sinh1

    def funcion_cosh(y):
        cosh1 = ((e ** y) + (e ** -y)) / 2

        return cosh1

    tanh_1 = funcion_sinh(y) / funcion_cosh(y)

    print("El resultado de la función Tanh es: ", tanh_1)

ReLu(5)
print(e)
Sigmoid(5)
funcion_Tanh(1)