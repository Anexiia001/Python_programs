#Práctica Operadores Asignación, Booleanos y Comparación
#Comparador de Longitudes de Palabras

def comparar_longitud(palabra1, palabra2):
    longitud1 = len(palabra1)
    longitud2 = len(palabra2)

    res = longitud1 == longitud2

    return res


pal1 = "'Janitacos'"
pal2 = "'Quesabirrias'"
longi_total = comparar_longitud(pal1, pal2)
print(f"¿Son {pal1} y {pal2} dos palabras con la misma longitud? {longi_total}")